Current Version: 1.4.2
======================
This software is allowed to use under GPL or you need to buy commercial license for better support or other purpose.
Please contact us at info@jeasyui.com
