var app = getApp()
Page({

    /**
     * 页面的初始数据
     */
    data: {
        iconUrl: {
            newImg: '../../images/icon/new.png'
        },
        scrollDatas: [
            {
                logo: "../../images/new/logo@2x.png",
                id: 1,
                name: "杜蕾斯",
                price: "66.66",
                unit: "盒"
            },
            {
                logo: "../../images/new/logo@2x.png",
                id: 1,
                name: "杜蕾斯",
                price: "66.66",
                unit: "盒"
            },
            {
                logo: "../../images/new/logo@2x.png",
                id: 1,
                name: "杜蕾斯",
                price: "66.66",
                unit: "盒"
            }, {
                logo: "../../images/new/logo@2x.png",
                id: 1,
                name: "杜蕾斯",
                price: "66.66",
                unit: "盒"
            }, {
                logo: "../../images/new/logo@2x.png",
                id: 1,
                name: "杜蕾斯",
                price: "66.66",
                unit: "盒"
            }, {
                logo: "../../images/new/logo@2x.png",
                id: 1,
                name: "杜蕾斯",
                price: "66.66",
                unit: "盒"
            }, {
                logo: "../../images/new/logo@2x.png",
                id: 1,
                name: "杜蕾斯",
                price: "66.66",
                unit: "盒"
            }, {
                logo: "../../images/new/logo@2x.png",
                id: 1,
                name: "杜蕾斯",
                price: "66.66",
                unit: "盒"
            }
        ],
        listDatas: [
            {
                logo: "../../images/new/logo@2x.png",
                id: 1,
                name: "杜蕾斯，低价风暴。让爱更安全，全球第一安全套品牌。杜蕾斯，低价风",
                price: "66.66",
                number: "666"
            },
            {
                logo: "../../images/new/logo@2x.png",
                id: 1,
                name: "杜蕾斯，低价风暴。让爱更安全，全球第一安全套品牌。杜蕾斯，低价风",
                price: "66.66",
                number: "666"
            },
            {
                logo: "../../images/new/logo@2x.png",
                id: 1,
                name: "杜蕾斯，低价风暴。让爱更安全，全球第一安全套品牌。杜蕾斯，低价风",
                price: "66.66",
                number: "666"
            }, {
                logo: "../../images/new/logo@2x.png",
                id: 1,
                name: "杜蕾斯，低价风暴。让爱更安全，全球第一安全套品牌。杜蕾斯，低价风",
                price: "66.66",
                number: "666"
            }, {
                logo: "../../images/new/logo@2x.png",
                id: 1,
                name: "杜蕾斯，低价风暴。让爱更安全，全球第一安全套品牌。杜蕾斯，低价风",
                price: "66.66",
                number: "666"
            }, {
                logo: "../../images/new/logo@2x.png",
                id: 1,
                name: "杜蕾斯，低价风暴。让爱更安全，全球第一安全套品牌。杜蕾斯，低价风",
                price: "66.66",
                number: "666"
            }, {
                logo: "../../images/new/logo@2x.png",
                id: 1,
                name: "杜蕾斯，低价风暴。让爱更安全，全球第一安全套品牌。杜蕾斯，低价风",
                price: "66.66",
                number: "666"
            }, {
                logo: "../../images/new/logo@2x.png",
                id: 1,
                name: "杜蕾斯，低价风暴。让爱更安全，全球第一安全套品牌。杜蕾斯，低价风",
                price: "66.66",
                number: "666"
            }
        ]
    },

    /**
     * 生命周期函数--监听页面加载
     */
    onLoad: function (options) {

    },

    /**
     * 生命周期函数--监听页面初次渲染完成
     */
    onReady: function () {

    },

    /**
     * 生命周期函数--监听页面显示
     */
    onShow: function () {

    },

    /**
     * 生命周期函数--监听页面隐藏
     */
    onHide: function () {

    },

    /**
     * 生命周期函数--监听页面卸载
     */
    onUnload: function () {

    },

    /**
     * 页面相关事件处理函数--监听用户下拉动作
     */
    onPullDownRefresh: function () {

    },

    /**
     * 页面上拉触底事件的处理函数
     */
    onReachBottom: function () {

    },

    /**
     * 用户点击右上角分享
     */
    onShareAppMessage: function () {

    },
    lookDetail: function (e) {
        app.lookDetail(e);
    }
})