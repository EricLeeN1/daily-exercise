// pages/goodsDetails/comments/comments.js
Page({

    /**
     * 页面的初始数据
     */
    data: {
        commentsLabelListsAll: 123 * 4,
        commentsLabelLists: [
            {
                name: "商家态度好",
                num: 123
            },
            {
                name: "物流速度快",
                num: 123
            },
            {
                name: "商品质量好",
                num: 123
            },
            {
                name: "物美价廉",
                num: 123
            }
        ],
        commentsLists: [
            {
                id: 1,
                avatarUrl: "../../../images/icon/logo.png",
                name: "客户1",
                time: "2017-10-30",
                des: "杜蕾斯，低价风暴，让爱更安全。全球第一安全套品牌，杜蕾斯，低价风暴，让爱更安全。全球第一安全套品牌。杜蕾斯...",
                color: "红色",
                size: "超大"
            },
            {
                id: 2,
                avatarUrl: "../../../images/icon/logo.png",
                name: "客户1",
                time: "2017-10-30",
                des: "杜蕾斯，低价风暴，让爱更安全。全球第一安全套品牌，杜蕾斯，低价风暴，让爱更安全。全球第一安全套品牌。杜蕾斯...",
                color: "红色",
                size: "超大"
            },
            {
                id: 3,
                avatarUrl: "../../../images/icon/logo.png",
                name: "客户1",
                time: "2017-10-30",
                des: "杜蕾斯，低价风暴，让爱更安全。全球第一安全套品牌，杜蕾斯，低价风暴，让爱更安全。全球第一安全套品牌。杜蕾斯...",
                color: "红色",
                size: "超大"
            },
            {
                id: 4,
                avatarUrl: "../../../images/icon/logo.png",
                name: "客户1",
                time: "2017-10-30",
                des: "杜蕾斯，低价风暴，让爱更安全。全球第一安全套品牌，杜蕾斯，低价风暴，让爱更安全。全球第一安全套品牌。杜蕾斯...",
                color: "红色",
                size: "超大"
            },
            {
                id: 5,
                avatarUrl: "../../../images/icon/logo.png",
                name: "客户1",
                time: "2017-10-30",
                des: "杜蕾斯，低价风暴，让爱更安全。全球第一安全套品牌，杜蕾斯，低价风暴，让爱更安全。全球第一安全套品牌。杜蕾斯...",
                color: "红色",
                size: "超大"
            }
        ]
    },

    /**
     * 生命周期函数--监听页面加载
     */
    onLoad: function (options) {

    },

    /**
     * 生命周期函数--监听页面初次渲染完成
     */
    onReady: function () {

    },

    /**
     * 生命周期函数--监听页面显示
     */
    onShow: function () {

    },

    /**
     * 生命周期函数--监听页面隐藏
     */
    onHide: function () {

    },

    /**
     * 生命周期函数--监听页面卸载
     */
    onUnload: function () {

    },

    /**
     * 页面相关事件处理函数--监听用户下拉动作
     */
    onPullDownRefresh: function () {

    },

    /**
     * 页面上拉触底事件的处理函数
     */
    onReachBottom: function () {

    },

    /**
     * 用户点击右上角分享
     */
    onShareAppMessage: function () {

    }
})